"""``kedro_datasets`` is where you can find all of Kedro's data connectors."""

__version__ = "1.2.0"
